from kafka import KafkaConsumer
import json
from apyori import apriori

# Kafka consumer settings
bootstrap_servers = ['localhost:9092']
topic_name = 'itemset_mining'
group_id = 'itemset_group'

# Initialize Kafka consumer
consumer = KafkaConsumer(topic_name,
                         group_id=group_id,
                         bootstrap_servers=bootstrap_servers,
                         auto_offset_reset='earliest',
                         value_deserializer=lambda x: json.loads(x.decode('utf-8')))

# Function to extract transactions from messages
def extract_transactions(messages):
    transactions = []
    for message in messages:
        also_buy = message.get('also_buy', [])
        transactions.append(also_buy)
    return transactions

# Function to apply Apriori algorithm
def apply_apriori(transactions, min_support=0.1):
    rules = apriori(transactions, min_support=min_support)
    return list(rules)

# Function to process messages
def process_message(message):
    record_number = message.get('record_number')
    title = message.get('title')
    asin = message.get('asin')
    also_buy = message.get('also_buy', [])
    also_view = message.get('also_view', [])

    print(f"Received message: Record {record_number}, Title: {title}, ASIN: {asin}")
    print(f"Also Buy: {also_buy}")
    print(f"Also View: {also_view}")
    print("\n")

# Consume messages from the Kafka topic
messages = []
for message in consumer:
    data = message.value
    process_message(data)
    messages.append(data)

# Extract transactions from messages
transactions = extract_transactions(messages)

# Apply Apriori algorithm
min_support = 0.5  # Adjust as needed
rules = apply_apriori(transactions, min_support=min_support)

# Print generated rules
print("Generated association rules:")
for rule in rules:
    print(rule)

