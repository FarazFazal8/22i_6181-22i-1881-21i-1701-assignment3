from kafka import KafkaConsumer
import json
from itertools import combinations
import hashlib

# Kafka consumer settings
bootstrap_servers = ['localhost:9092']
topic_name = 'pcy'

# PCY Algorithm Parameters
bitmap_size = 100   # Example bitmap size
support_threshold = 10  # Example support threshold

# Bitmap array for counting item pairs
bitmap = [0] * bitmap_size

# Function to process incoming messages and implement PCY algorithm
def process_messages():
    consumer = KafkaConsumer(topic_name, bootstrap_servers=bootstrap_servers,
                             value_deserializer=lambda v: json.loads(v.decode('utf-8')))
    
    try:
        for message in consumer:
            transaction = message.value
            
            # Extract items from the transaction
            items = transaction.get('also_buy', [])  # Example: Use 'also_buy' as transaction items
            
            # Generate and count item pairs
            for i in range(len(items)):
                for j in range(i + 1, len(items)):
                    item_pair = tuple(sorted([items[i], items[j]]))
                    hash_value = hashlib.sha256(':'.join(item_pair).encode()).hexdigest()
                    hash_index = int(hash_value, 16) % bitmap_size
                    
                    # Increment corresponding bitmap cell if within range
                    if hash_index < bitmap_size:
                        bitmap[hash_index] += 1
            
            # Check bitmap for frequent item pairs and print
            frequent_itemsets = []
            for i in range(len(bitmap)):
                if bitmap[i] >= support_threshold:
                    # Reconstruct frequent item pair from hash index `i`
                    frequent_item_pair = ...  # Implement reconstruction logic
                    frequent_itemsets.append(frequent_item_pair)
            
            # Print frequent itemsets
            if frequent_itemsets:
                print(f"Frequent Itemsets: {frequent_itemsets}")
    
    except Exception as e:
        print(f"Error occurred: {e}")
    finally:
        consumer.close()

# Execute PCY algorithm on incoming messages
if __name__ == "__main__":
    process_messages()

