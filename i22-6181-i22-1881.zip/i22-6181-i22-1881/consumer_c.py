from kafka import KafkaConsumer
import json
from collections import defaultdict

def generate_candidates(frequent_items):
    candidates = set()
    for item1 in frequent_items:
        for item2 in frequent_items:
            if item1 != item2:
                candidates.add(tuple(sorted([item1, item2])))
    return candidates

def count_support(transactions, candidates):
    itemset_counts = defaultdict(int)
    for transaction in transactions:
        for candidate in candidates:
            if set(candidate).issubset(transaction):
                itemset_counts[candidate] += 1
    return itemset_counts

def main():
    consumer = KafkaConsumer('itemset_mining', bootstrap_servers=['localhost:9092'],
                             value_deserializer=lambda x: json.loads(x.decode('utf-8')))

    threshold = 1000  # Set your suitable threshold here
    transactions = []
    frequent_items_set = set()
    
    for message in consumer:
        json_data = message.value
        transactions.append(json_data["also_buy"])

        # Generate candidates for frequent itemsets
        if not frequent_items_set:
            frequent_items_set = set(json_data["also_buy"])
        else:
            candidates = generate_candidates(frequent_items_set)

            # Count support for candidates
            itemset_counts = count_support(transactions, candidates)

            # Filter candidates with support above threshold
            frequent_items_set = {item for item, count in itemset_counts.items() if count >= threshold}

        if len(frequent_items_set) > 0:
            print("Frequent Itemset satisfying threshold:", frequent_items_set)

if __name__ == "__main__":
    main()

