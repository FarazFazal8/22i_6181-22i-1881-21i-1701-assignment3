from kafka import KafkaProducer
import json
import os

# Kafka producer settings
bootstrap_servers = ['localhost:9092']
topic_name = 'itemset_mining'

# Function to load data from JSON file and send to Kafka topic
def send_data_to_kafka():
    # Initialize Kafka producer
    producer = KafkaProducer(bootstrap_servers=bootstrap_servers,
                             value_serializer=lambda v: json.dumps(v).encode('utf-8'))

    # File path for cleaned_records.json
    file_path = '/home/i226181/kafka/cleaned_records.json'

    # Check if the file exists
    if not os.path.exists(file_path):
        print(f"File {file_path} does not exist.")
        return

    # Load data from cleaned_records.json
    with open(file_path, 'r', encoding='utf-8') as file:
        for idx, line in enumerate(file, start=1):
            data = json.loads(line)

            # Extract required fields
            title = data.get('title')
            asin = data.get('asin')
            also_buy = data.get('also_buy', [])
            also_view = data.get('also_view', [])

            # Prepare message payload
            message = {
                'record_number': idx,
                'title': title,
                'asin': asin,
                'also_buy': also_buy,
                'also_view': also_view
            }

            # Print title, ASIN number, and record number
            print(f"Record {idx}: Title: {title}, ASIN: {asin}")

            # Send message to Kafka topic
            producer.send(topic_name, value=message)

    # Flush and close the producer
    producer.flush()
    producer.close()

if __name__ == "__main__":
    send_data_to_kafka()
